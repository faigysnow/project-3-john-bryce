<?php
    class Model {
        private $tableName;
        public $tableRows = array();

        public function getRows(){
            return $this->tableRows;
        }


        
        
    }