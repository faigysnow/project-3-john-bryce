    // Administrator module


    function Administator(data) {
        // let valN = validate.All(data);
        // if (!valN)
        //     throw "error";
        this.name = data.name;
        this.role = data.role;
        this.phone = data.phone;
        this.email = data.email;
        this.password = data.password;


    }



    // getname: function() {
    //     let valN = validate.ValidateName(this.name);
    //     if (valN == true) return this.name;
    //     else return false;
    // },

    // getid: function() {
    //     let valid = validate.ValidateId(this.id);
    //     if (valid == true) return this.id;
    //     else return false;
    // },

    // getmanu: function() {
    //     let valid = validate.ValidateName(this.manu);
    //     if (valid == true) return this.manu;
    //     else return false;
    // }, 

    // getimage: function() {
    //     let valid = validate.ValidateName(this.image);
    //     if (valid == true) return this.image;
    //     else return false;
    // }